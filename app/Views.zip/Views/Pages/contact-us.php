<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

    <section class="breadcrumbs mt-3 mb-2">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="home">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="single-main">
        <div class="container">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-12 col-12 forpadding">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-12 mb-4 forpadding">
                            <div class="rygames">
                                <h3 for-h3>Contact Us</h3>
                                <p class="for16 mt-3">If you want to Contact APKSure administrator, Send your suggestions, Report website bugs, or Submit your apps, Please contact us using the following way:</p>
                                <ul class="forpadding2">
                                    <li class="for16 forcircle">Send Email: <b>support@apksure.com</b></li>
                                    <li class="for16 forcircle">Feedback</li>
                                </ul>
                                <div class="border col-xl-12 col-lg-12 col-md-12 col-12  p-4 ">
                                    <form class="form forpadding for16" method="post">
                                        <div class="form-group">
                                            <label class="forlabel">Your name *</label>
                                            <input type="text" class="form-control" name="name" placeholder="Your name" value="" data-required="">

                                        </div>
                                        <div class="form-group">
                                            <label class="forlabel">Your email *</label>
                                            <input type="email" class="form-control" name="email" placeholder="Your email" value="" data-required="" data-pattern="^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$">
                                        </div>
                                        <div class="form-group">
                                            <label class="forlabel">Subject *</label>
                                            <input type="text" name="subject" class="form-control" value="" placeholder="Subject" data-required="">
                                        </div>
                                        <div class="form-group">
                                            <label class="forlabel">Reason for contact *</label>
                                        </div>

                                        <div class=" form-group ml-2">
                                            <div class="form-check-inline"><label class="form-check-label"><input class="form-check-input"  type="radio" name="reason" value="feedback" checked="" data-required="">Comments and feedback</label></div>
                                            <div class="form-check-inline"><label class="form-check-label"><input type="radio" class="form-check-input"  name="reason" value="report_problem" data-required="">Report a problem</label></div>
                                            <div class="form-check-inline"><label class="form-check-label"><input type="radio" name="reason" class="form-check-input"  value="dmca_takedown_request" data-required="">DMCA takedown request</label></div>
                                            <div class="form-check-inline"><label class="form-check-label"><input type="radio" name="reason" class="form-check-input"  value="developer" data-required="">Developer Support and Feedback</label></div>
                                            <div class="form-check-inline"><label class="form-check-label"><input type="radio"  name="reason" class="form-check-input"  value="other" data-required="">Others</label></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="forlabel">Your message </label>
                                            <textarea name="message" rows="5" class="form-control" placeholder="Questions or Comments" data-required=""></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label class="forlabel">Verification code *</label> <br>
                                            <input style="width: 180px" type="text " name="captcha " placeholder="Verification code" data-required=" ">
                                            <a id="captcha_a " title="Chang Code " href="javascript:void(0) " data-src="https://a.apkpure.com/captcha "><img style="height: 32px; border: 1px solid #ccc; margin-top: -3px; border-radius: 3px; " id="captcha_img
                                            " src="https://a.apkpure.com/captcha?0.30912273505786025 "></a>
                                        </div>
                                        <div class="form-group " style="display: none "></div>
                                        <button type="submit " class="form-control mt-4 py-2 btn">Send</button>
                                    </form>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-12 col-12 forpadding sidbr ">
                    <div class="ulsocl ">
                        <li><a href="# "><i class="fab fa-facebook "></i>Facebook </a></li>
                        <li><a href="# "><i class="fab fa-twitter " aria-hidden="true "></i>Twitter</a></li>
                        <li><a href="# "><i class="fab fa-youtube "></i>YouTube</a></li>
                    </div>
                    <div class="disv mt-4 mb-4 ">
                        <!-- <h2>Discover</h2> -->
                        <ul>
                            <li>Most Popular In Today</li>
                            <li><a href="# ">More >></a></li>
                        </ul>
                        <div class="gmesct ">
                            <div class="gmimg ">
                                <img src="<?php echo base_url('assets/images'); ?>/gmimg2.png ">
                            </div>
                            <div class="gmcon ">
                                <h4>Deep 6 - Awakening</h4>
                                <p>Role Playing</p>
                                <p class="cate "><span>Free </span> <del>$1.49</del></p>
                            </div>

                        </div>
                        <div class="gmesct ">
                            <div class="gmimg ">
                                <img src="<?php echo base_url('assets/images'); ?>/img-single.png ">
                            </div>
                            <div class="gmcon ">
                                <h4>Wenpo - Icon Pack</h4>
                                <p>Personalization</p>
                                <p class="cate "><span>Free </span> <del>$0.99</del></p>
                            </div>

                        </div>

                        <div class="gmesct ">
                            <div class="gmimg ">
                                <img src="<?php echo base_url('assets/images'); ?>/gmimg.png ">
                            </div>
                            <div class="gmcon ">
                                <h4>Hills Legend: Action-horror</h4>
                                <p>Action</p>
                                <p class="cate "><span>Free </span> <del>$1.49</del></p>
                            </div>

                        </div>

                        <div class="gmesct ">
                            <div class="gmimg ">
                                <img src="<?php echo base_url('assets/images'); ?>/gmimg2.png ">
                            </div>
                            <div class="gmcon ">
                                <h4>Deep 6 - Awakening</h4>
                                <p>Role Playing</p>
                                <p class="cate "><span>Free </span> <del>$1.49</del></p>
                            </div>

                        </div>
                        <div class="gmesct ">
                            <div class="gmimg ">
                                <img src="<?php echo base_url('assets/images'); ?>/img-single.png ">
                            </div>
                            <div class="gmcon ">
                                <h4>Wenpo - Icon Pack</h4>
                                <p>Personalization</p>
                                <p class="cate "><span>Free </span> <del>$0.99</del></p>
                            </div>

                        </div>


                    </div>

                </div>
            </div>
        </div>
    </section>

<?= $this->endSection() ?>
