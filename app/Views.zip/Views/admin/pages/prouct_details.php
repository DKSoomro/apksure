
            <div class="modal fade" id="prodctview" tabindex="-1" role="dialog" aria-labelledby="prodctview" style="display: none; " aria-modal="true">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel-2">Product View</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">×</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <div class="row">
                              <div class="col-md-12 grid-margin">
                                <div class="card">
                                  <div class="card-body">
                                    <h4 class="card-title">Default Responsive Table</h4>
                                    <div class="table-responsive">
                                      <table id="order-listing" class="table">
                                        <thead>
                                          <tr>
                                            <th>Id #</th>
                                            <th>Products Name</th>
                                            <th>Products Category</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                         
                                      
                                        </tbody>
                                      </table>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>  
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                          </div>
                        </div>
                      </div>
                    </div>