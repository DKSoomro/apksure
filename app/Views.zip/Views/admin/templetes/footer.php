          <footer class="footer">
            <div class="container-fluid clearfix">
              <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2020 <a href="http://www.bootstrapdash.com/" target="_blank">APKSure</a>. All rights reserved.</span>
              <!-- <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i> -->
              </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?= base_url(); ?>/assets/admin/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="<?= base_url(); ?>/assets/admin/vendors/chart.js/Chart.min.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/vendors/jvectormap/jquery-jvectormap.min.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/vendors/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/vendors/justgage/raphael-2.1.4.min.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/vendors/justgage/justgage.js"></script>
        <script src="<?= base_url(); ?>/assets/admin/vendors/select2/select2.min.js"></script>

    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?= base_url(); ?>/assets/admin/js/shared/off-canvas.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/js/shared/hoverable-collapse.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/js/shared/misc.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/js/shared/settings.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/js/shared/todolist.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="<?= base_url(); ?>/assets/admin/js/demo_1/dashboard.js"></script>
        <script src="<?= base_url(); ?>/assets/admin/js/shared/select2.js"></script>
            <script src="<?= base_url(); ?>/assets/admin/js/shared/file-upload.js"></script>
                <script src="<?= base_url(); ?>/assets/admin/js/shared/data-table.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/vendors/datatables.net/jquery.dataTables.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/vendors/datatables.net-fixedcolumns/dataTables.fixedColumns.min.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/vendors/jquery-validation/jquery.validate.min.js"></script>
    <script src="<?= base_url(); ?>/assets/admin/vendors/tinymce/tinymce.min.js"></script>
    <!-- <script src="<?= base_url(); ?>/assets/admin/js/shared/form-validation.js"></script> -->
    <script src="<?= base_url(); ?>/assets/admin/js/custom.js"></script>

    <!-- End custom js for this page -->
  </body>
</html>