  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>APKSure</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/ti-icons/css/themify-icons.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/typicons/typicons.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/select2/select2.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/icheck/all.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/jvectormap/jquery-jvectormap.css">
    <!-- End Plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/css/shared/style.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/font-awesome/css/font-awesome.min.css" />
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/css/style.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/css/custom.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/admin/vendors/datatables.net-fixedcolumns-bs4/fixedColumns.bootstrap4.min.css">
    <!-- End Layout styles -->
    <link rel="shortcut icon" href="<?= base_url(); ?>/assets/images/logo.png" />
    <script type="text/javascript">
        var base_url = '<?= base_url(); ?>'
    </script>
  </head>