<?= $this->include('Template/header') ?>

<?= $this->renderSection('content') ?>

<?= $this->include('Template/footer') ?>